<?php $__env->startSection('title', 'Liste des utilisateurs'); ?>

<?php $__env->startSection('content'); ?>
        <h1 class="text-center mb-4">Liste des utilisateurs</h1>
        <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
         <?php endif; ?>
         <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
         <?php endif; ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>Nom</th>
                        <th>Email</th>
                        <th>Rôle</th>
                        <th>Statut</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td>
                        <span class="badge <?php echo e($user->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($user->is_active ? 'Actif' : 'Inactif'); ?>

                        </span>
                    </td>
                    <td>
                        <!-- Modifier -->
                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn btn-warning btn-sm">Modifier</a>

                        <!-- Activer/Désactiver -->
                        <form action="<?php echo e(route('admin.users.toggleStatus', $user->id)); ?>" method="post" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-primary btn-sm">
                                <?php echo e($user->is_active ? 'Désactiver' : 'Activer'); ?>

                            </button>
                        </form>

                        <!-- Supprimer -->
                        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="post" class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur ?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                        </form>
                    </td>
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anis/Bureau/login-test/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>