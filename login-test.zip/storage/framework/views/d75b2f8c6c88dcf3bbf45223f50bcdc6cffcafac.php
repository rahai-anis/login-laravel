<?php $__env->startSection('title', 'Modifier les utilisateurs'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="mb-4">Modifier l'utilisateur</h1>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label class="form-label">Nom</label>
        <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
    </div>

    <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
    </div>
    <div class="mb-3">
            <label class="form-label">Nouveau Mot de Passe (optionnel)</label>
            <input type="password" name="password" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Confirmer le Mot de Passe</label>
            <input type="password" name="password_confirmation" class="form-control">
        </div>

    <button type="submit" class="btn btn-success">Enregistrer</button>
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary">Annuler</a>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anis/Bureau/login-test/resources/views/admin/edit-user.blade.php ENDPATH**/ ?>