<?php $__env->startSection('title', 'user'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
         <?php endif; ?>
<div class="container">
        <h1>Bienvenue, <?php echo e(auth()->user()->name); ?></h1>
        <p>Ceci est votre tableau de bord utilisateur.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anis/Bureau/login-test/resources/views/users/user.blade.php ENDPATH**/ ?>